
package Common;

/**
 * Enumerator of Cashier State
 * @author Rafael Sá (104552), Luís Laranjeira (81526)
 */
public enum STCashier {
    IDLE,
    PAYMENT_HALL,
    PAYMENT_BOX,
    STOP,
    END;
}
