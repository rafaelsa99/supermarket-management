
package Common;

/**
 * Enumerator of Manager State
 * @author Rafael Sá (104552), Luís Laranjeira (81526)
 */
public enum STManager {
    CORRIDOR_HALL_1,
    CORRIDOR_HALL_2,
    CORRIDOR_HALL_3,
    ENTRANCE_HALL,
    IDLE,
    STOP,
    END;
}