
package SACashier;

/**
 *
 * @author Rafael Sá (104552), Luís Laranjeira (81526)
 */
public interface ICashier_Customer {

    public void paymentHall_customerIn();
    public void paymentHall_freeSlot();

}
