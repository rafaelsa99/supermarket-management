
package SACashier;

import Common.STCashier;

/**
 *
 * @author luisc
 */
public interface ICashier_Cashier {

    public STCashier idle();
}
